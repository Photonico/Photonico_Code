#!/usr/bin/env python3
"""Reproducible HarfBuzz default/optional-feature audit. Requires fontTools + hb-shape."""
import json, subprocess, unicodedata, pathlib, sys
from fontTools.ttLib import TTFont
HB='/opt/homebrew/bin/hb-shape'
FONTS={
 'baseline':'audit/generated/Photonico-current.ttf',
 'candidate_raw':'audit/review-claude/generated/current-raw.ttf',
 'candidate_built':'audit/review-claude/generated/current-built.ttf',
}
OUT=pathlib.Path('audit/review-claude/shaping'); OUT.mkdir(parents=True,exist_ok=True)

def shape(font,text,features=None,shaper='ot'):
 cmd=[HB,font,'--output-format=json','--shapers='+shaper,'--verify']
 if features: cmd+=['--features='+features]
 return [json.loads(line) for line in subprocess.check_output(cmd,input=text.encode()).decode().splitlines()]

def summarized(text,result):
 return {'text':text,'codepoints':[f'U+{ord(c):04X}' for c in text],'advance':sum(x['ax'] for x in result),'glyphs':result}

programming=['a==b','a===b','a!=b','a!==b','<=','>=','<>','<=>','=>','->','<--','-->','<->','->>','<<-','>>=','<<=','&&','||','::',':::','..','...','..<','..=','==>','<==','<==>','|>','<|','<|>','[|','|]','{|','|}','/*','*/','//','///','<!--','-->','www','0xFF','10.0','1/2','12/34','<$>','$>','<$','$$','`','``','```','````','a<b>c','abc_def','\\n','\\\\','#{','#[','#:']
marks_text=['x'+chr(cp) for cp in range(0x300,0x370)]
results={}
for label,path in FONTS.items():
 font=TTFont(path); cmap=font.getBestCmap()
 features=sorted({x.FeatureTag for x in font['GSUB'].table.FeatureList.FeatureRecord})
 gdef=font['GDEF'].table.GlyphClassDef.classDefs
 mark_coverage=set(g for l in font['GPOS'].table.LookupList.Lookup for st in l.SubTable if hasattr(st,'MarkCoverage') for g in st.MarkCoverage.glyphs)
 mark_text=['x'+chr(cp) for cp in cmap if unicodedata.category(chr(cp)) in ('Mn','Me')]
 mark_runs=shape(path,'\n'.join(mark_text))
 mark_data=[]
 for s,run in zip(mark_text,mark_runs):
  cp=ord(s[-1]); g=cmap[cp]
  rec=summarized(s,run)
  rec.update({'unicode_name':unicodedata.name(s[-1]),'nominal_glyph':g,'nominal_advance':font['hmtx'][g][0],'gdef_class':gdef.get(g),'gpos_mark_coverage':g in mark_coverage})
  mark_data.append(rec)
 prog_runs=shape(path,'\n'.join(programming)); prog=[summarized(s,r) for s,r in zip(programming,prog_runs)]
 prog_off=shape(path,'\n'.join(programming),'calt=0')
 matrix={}
 corpus='aAgGIilLrRsSuyY0123456789 $ <$> $> <= >= @ & ~ ? / \\ () [] {} +- = => -> --> ``` 1/2 12/34 1st 2nd'
 for feat in features:
  if feat=='aalt': continue
  run=shape(path,corpus,feat+'=1')[0]
  matrix[feat]=summarized(corpus,run)
 # Canonical equivalents should have equivalent glyph/position sequences, ignoring cluster numbering.
 decomp=[]
 for cp in cmap:
  ch=chr(cp); nfd=unicodedata.normalize('NFD',ch)
  if nfd!=ch and all(ord(c) in cmap for c in nfd): decomp.append((ch,nfd))
 eq_runs=shape(path,'\n'.join(s for pair in decomp for s in pair))
 normalized=lambda row:[{k:v for k,v in g.items() if k!='cl'} for g in row]
 eq_mismatches=[]
 for i,(nfc,nfd) in enumerate(decomp):
  r1,r2=eq_runs[i*2:i*2+2]
  if normalized(r1)!=normalized(r2): eq_mismatches.append({'nfc':summarized(nfc,r1),'nfd':summarized(nfd,r2)})
 # Exhaustive optional features with every encoded character, one line per scalar.
 full='\n'.join(chr(cp) for cp in cmap if cp not in (10,13))
 optional_non_grid={}
 for feat in features:
  if feat=='aalt': continue
  runs=shape(path,full,feat+'=1')
  defects=[]
  for s,run in zip(full.splitlines(),runs):
   # Intentional mark spacing/default ignorable behavior is considered separately.
   if unicodedata.category(s[0]) not in ('Mn','Me','Cf') and any(g['ax'] not in (0,1200) for g in run): defects.append(summarized(s,run))
  if defects: optional_non_grid[feat]=defects
 results[label]={'path':path,'features':features,'combining_marks':mark_data,'programming_samples':prog,'programming_width_failures':[r for r in prog if r['advance']!=1200*len(r['text'])],'calt_changes':[{'text':s,'on':r,'off':r0} for s,r,r0 in zip(programming,prog_runs,prog_off) if normalized(r)!=normalized(r0)],'feature_samples':matrix,'nfc_nfd_pairs_tested':len(decomp),'nfc_nfd_mismatches':eq_mismatches,'optional_feature_non_grid':optional_non_grid}
 print(label,'marks',len(mark_data),'NFC/NFD',len(decomp),'mismatch',len(eq_mismatches),'programming failures',[(r['text'],r['advance']) for r in results[label]['programming_width_failures']],'features non-grid',list(optional_non_grid))
(OUT/'shaping_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
