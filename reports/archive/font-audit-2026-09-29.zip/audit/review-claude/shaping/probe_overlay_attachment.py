from fontTools.ttLib import TTFont
from fontTools.feaLib.builder import addOpenTypeFeaturesFromString
import subprocess,json,pathlib
OUT=pathlib.Path('audit/review-claude/shaping')
f=TTFont('audit/review-claude/generated/current-built.ttf')
features='''languagesystem DFLT dflt;
languagesystem latn dflt;
markClass uni0335 <anchor 600 0> @OVERLAY;
markClass uni0336 <anchor 600 0> @OVERLAY;
feature mark {
 pos base [x uni25CC uni1D538 uni1D53C hyphen_hyphen.liga greater_equal_end.seq i.salt_low] <anchor 600 0> mark @OVERLAY;
} mark;
'''
# Diagnostic only: deliberately minimal GPOS, not a release candidate.
addOpenTypeFeaturesFromString(f,features,tables=['GPOS','GDEF'])
p=OUT/'diagnostic-overlay-markbase.ttf'; f.save(p)
texts=['x\u0335x','x\u0336x','◌\u0336','𝔼\u0336','--\u0335']
res={}
for shaper in ['ot','coretext']:
 rows=[json.loads(s) for s in subprocess.check_output(['/opt/homebrew/bin/hb-shape',str(p),'--output-format=json','--shapers='+shaper],input='\n'.join(texts).encode()).decode().splitlines()]
 res[shaper]=[{'text':s,'advance':sum(g['ax'] for g in row),'glyphs':row} for s,row in zip(texts,rows)]
 print(shaper,[(x['text'],x['advance']) for x in res[shaper]])
(OUT/'diagnostic-overlay-markbase.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
