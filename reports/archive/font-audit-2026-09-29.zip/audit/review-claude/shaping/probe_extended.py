from pathlib import Path
import json,unicodedata as ud,subprocess
from fontTools.ttLib import TTFont
FONTS={'baseline':'audit/generated/Photonico-current.ttf','candidate_raw':'audit/review-claude/generated/current-raw.ttf','candidate_built':'audit/review-claude/generated/current-built.ttf'}
HB='/opt/homebrew/bin/hb-shape'; OUT=Path('audit/review-claude/shaping')
def runs(path,texts,feat=None,shaper='ot'):
 args=[HB,path,'--output-format=json','--shapers='+shaper,'--verify']
 if feat:args+=['--features='+feat]
 return [json.loads(x) for x in subprocess.check_output(args,input='\n'.join(texts).encode()).decode().splitlines()]
res={}
for label,path in FONTS.items():
 f=TTFont(path); cmap=f.getBestCmap()
 texts=[chr(cp)+'\u0302' for cp in cmap if ud.category(chr(cp)).startswith('L') and ('LATIN' in ud.name(chr(cp),'') or 'GREEK' in ud.name(chr(cp),''))]
 rows=runs(path,texts); fail=[]
 for s,row in zip(texts,rows):
  if len(row)>1 and row[-1]['dx']==0:fail.append({'text':s,'codepoint':f'U+{ord(s[0]):04X}','name':ud.name(s[0]),'glyphs':row})
 probes=['x\u0335','x\u0336','\u0335','\u0336','\u25cc\u0335','\u25cc\u0336','𝔸\u0335','𝔼\u0336','x\u0335\u0302','x\u0302\u0335','x\u0323\u0302','x\u0335\u0300','x\u0335\u0323','x\u0335\u0336','x\u200d\u0335','x\u200b\u0335','x\u034f\u0335','=>\u0335','fi\u0335','--\u0335','a\u0325\u0301','ḍ\u0301','d\u0323\u0301','r\u0302','r\u0300','r\u030C','Λ\u0302','ϕ\u0302','œ\u0302','x\u0302\u0301','x\u0308\u0301','ā\u0301','\u25cc\u0323']
 probe_rows=runs(path,probes)
 variants={}
 for feat in ['ss01','cv01','cv03','cv04','cv05','cv06','mark=0','mkmk=0']:
  texts2=['r\u0302','r\u0325','a\u030F','a\u0323','i\u030F','i\u0325','x\u0335','x\u0300']
  variants[feat]=[{'text':s,'glyphs':row} for s,row in zip(texts2,runs(path,texts2,feat))]
 res[label]={'letter_circumflex_tested':len(texts),'missing_attachment':fail,'extended_probes':[{'text':s,'glyphs':row} for s,row in zip(probes,probe_rows)],'feature_probes':variants,'coretext_probes':[{'text':s,'glyphs':row} for s,row in zip(probes,runs(path,probes,shaper='coretext'))]}
 print(label,'tested',len(texts),'missing',len(fail))
(OUT/'extended_results.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
