from pathlib import Path
import json,collections
from fontTools.ttLib import TTFont
from fontTools.ttLib.tables._c_m_a_p import CmapSubtable
from PIL import Image,ImageFont,ImageChops
ROOT=Path('/Users/lu/Repos/Photonico_Code');OUT=ROOT/'audit/review-claude/source'
mapping=json.load(open(OUT/'name_mapping.json'));before=list(mapping);sources=[ROOT/'audit/generated/Photonico-current.ttf',ROOT/'audit/review-claude/generated/current-raw.ttf']
fonts=[]
for i,p in enumerate(sources):
 f=TTFont(p);cm=CmapSubtable.newSubtable(12);cm.platformID=3;cm.platEncID=10;cm.language=0;cm.cmap={0xF0000+j:n if i==0 else mapping[n] for j,n in enumerate(before)};f['cmap'].tables=[cm]
 dest=OUT/('before-render.ttf' if i==0 else 'after-render.ttf');f.save(dest);fonts.append(ImageFont.truetype(str(dest),240,layout_engine=ImageFont.Layout.BASIC))
def raster(font,char):
 m,off=font.getmask2(char,mode='L',anchor='ls');im=Image.frombytes('L',m.size,bytes(m));box=im.getbbox()
 if not box:return Image.new('L',(1,1),0),(0,0,0,0)
 return im.crop(box),(box[0]+off[0],box[1]+off[1],box[2]+off[0],box[3]+off[1])
changed=[]
for j,n in enumerate(before):
 ims=[raster(f,chr(0xF0000+j)) for f in fonts]
 if ims[0][0].tobytes()==ims[1][0].tobytes() and ims[0][1]==ims[1][1]:continue
 bs=[im[1] for im in ims];b=(min(x[0] for x in bs),min(x[1] for x in bs),max(x[2] for x in bs),max(x[3] for x in bs));can=[]
 for im,bb in ims:
  c=Image.new('L',(max(1,b[2]-b[0]),max(1,b[3]-b[1])),0);c.paste(im,(bb[0]-b[0],bb[1]-b[1]));can.append(c)
 diff=ImageChops.difference(*can);hist=diff.histogram();count=sum(hist[1:]);s=sum(i*v for i,v in enumerate(hist));count32=sum(hist[32:]);count128=sum(hist[128:]);maxdiff=diff.getextrema()[1]
 if not count:continue
 row={'before':n,'after':mapping[n],'before_bbox':bs[0],'after_bbox':bs[1],'changed_pixels':count,'pixels_diff_ge32':count32,'pixels_diff_ge128':count128,'mean_difference':round(s/count,2),'max_difference':maxdiff}
 changed.append(row)
 if count128>0:
  safe=n.replace('/','_');can[0].save(OUT/f'pixel-before-{safe}.png');can[1].save(OUT/f'pixel-after-{safe}.png')
(OUT/'raster_changes_240px.json').write_text(json.dumps(sorted(changed,key=lambda r:r['pixels_diff_ge128'],reverse=True),indent=2))
print('changed',len(changed),'of',len(before));print(json.dumps(sorted(changed,key=lambda r:r['pixels_diff_ge128'],reverse=True)[:90],indent=2))
