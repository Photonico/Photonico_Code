import fontforge,pathlib,json,hashlib,collections
ROOT=pathlib.Path('/Users/lu/Repos/Photonico_Code');OUT=ROOT/'audit/review-claude/source'
def digest(x):return hashlib.sha256(json.dumps(x,separators=(',',':'),sort_keys=True).encode()).hexdigest()
def canonical(c):
 p=[(round(x.x,7),round(x.y,7),int(x.on_curve)) for x in c]
 if len(p)>1 and p[0]==p[-1]:p.pop()
 if not p:return []
 variants=[]
 for q in [p,list(reversed(p))]:
  m=min(q)
  variants += [q[i:]+q[:i] for i,v in enumerate(q) if v==m]
 return min(variants)
def boxes(f,name,t=(1,0,0,1,0,0)):
 g=f[name];rs=[]
 for c in g.foreground:
  if len(c)>1:rs.append(c.transform(t).boundingBox())
 for ref,u,selected in g.references:
  a,b,c,d,e,ff=t;A,B,C,D,E,F=u
  rs+=boxes(f,ref,(a*A+c*B,b*A+d*B,a*C+c*D,b*C+d*D,a*E+c*F+e,b*E+d*F+ff))
 return rs
results={}
for state,path in [('before',OUT/'before.sfd'),('after',ROOT/'00_Regular.sfd')]:
 f=fontforge.open(str(path));rows={};linenos={};start=None
 for i,line in enumerate(path.read_text().splitlines(),1):
  if line.startswith('StartChar: '):start=line[11:];linenos[start]=i
 for g in f.glyphs():
  contours=[];canon=[]
  for c in g.foreground:
   cc=canonical(c)
   contours.append({'length':len(c),'closed':bool(c.closed),'bbox':c.boundingBox(),'hash':digest(cc)})
   if len(c)>1:canon.append(digest(cc))
  b=boxes(f,g.glyphname);bbox=[min(x[0] for x in b),min(x[1] for x in b),max(x[2] for x in b),max(x[3] for x in b)] if b else [0,0,0,0]
  refs=[(n,t) for n,t,s in g.references]
  rows[g.glyphname]={'line':linenos[g.glyphname],'unicode':g.unicode,'width':g.width,'bbox':bbox,'contours':contours,'shape_hash':digest(sorted(canon)),'refs':refs,'anchors':g.anchorPoints,'validation':g.validate(True),'ttinstrs':len(g.ttinstrs)}
 results[state]=rows;f.close();print(state,'glyphs',len(rows),'flags', {hex(1<<i):sum(bool(r['validation']&(1<<i)) for r in rows.values()) for i in range(25) if any(r['validation']&(1<<i) for r in rows.values())},flush=True)
(OUT/'geometry_comparison.json').write_text(json.dumps(results,ensure_ascii=False,separators=(',',':')))
a=results['before'];b=results['after'];summary={'removed':sorted(set(a)-set(b)),'added':sorted(set(b)-set(a))}
for field in ['shape_hash','refs','width','unicode','bbox','anchors']:
 summary[field+'_changed']=[n for n in a.keys()&b.keys() if a[n][field]!=b[n][field]]
print(json.dumps(summary,ensure_ascii=False,indent=2))
(OUT/'geometry_changes.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
