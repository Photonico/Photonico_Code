#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ft2build.h>
#include FT_FREETYPE_H
struct Raster { int l,t,w,h; unsigned char *p; };
static struct Raster draw(FT_Face f,unsigned long u){
 int err=FT_Load_Char(f,u,FT_LOAD_NO_HINTING|FT_LOAD_NO_BITMAP); if(err){fprintf(stderr,"load %lu: %d\n",u,err);exit(2);}
 err=FT_Render_Glyph(f->glyph,FT_RENDER_MODE_NORMAL);if(err){fprintf(stderr,"render: %d\n",err);exit(2);}
 FT_Bitmap *b=&f->glyph->bitmap;struct Raster r={f->glyph->bitmap_left,f->glyph->bitmap_top,b->width,b->rows,NULL};
 r.p=calloc((r.w*r.h)?r.w*r.h:1,1);
 for(int y=0;y<r.h;y++)memcpy(r.p+y*r.w,b->buffer+y*b->pitch,r.w);
 return r;
}
static int at(struct Raster r,int x,int y){ x-=r.l;y-=r.t-r.h; if(x<0||x>=r.w||y<0||y>=r.h)return 0; return r.p[(r.h-1-y)*r.w+x]; }
int main(int argc,char **argv){
 if(argc!=4)return 1;FT_Library lib;FT_Face faces[2];FT_Init_FreeType(&lib);
 for(int f=0;f<2;f++){if(FT_New_Face(lib,argv[1+f],0,&faces[f]))return 2;FT_Set_Pixel_Sizes(faces[f],0,240);}
 int count=atoi(argv[3]);printf("[\n");int first=1;
 for(int i=0;i<count;i++){
 struct Raster a=draw(faces[0],0xF0000+i),b=draw(faces[1],0xF0000+i);
 int l=a.l<b.l?a.l:b.l, bot=a.t-a.h<b.t-b.h?a.t-a.h:b.t-b.h, rr=a.l+a.w>b.l+b.w?a.l+a.w:b.l+b.w, top=a.t>b.t?a.t:b.t;
 int changed=0,c32=0,c128=0,maxdiff=0;long sum=0;
 for(int y=bot;y<top;y++)for(int x=l;x<rr;x++){int d=abs(at(a,x,y)-at(b,x,y));if(d){changed++;sum+=d;}if(d>=32)c32++;if(d>=128)c128++;if(d>maxdiff)maxdiff=d;}
 if(changed){if(!first)printf(",\n");first=0;printf("{\"index\":%d,\"changed_pixels\":%d,\"pixels_diff_ge32\":%d,\"pixels_diff_ge128\":%d,\"max_difference\":%d,\"sum_difference\":%ld}",i,changed,c32,c128,maxdiff,sum);}
 free(a.p);free(b.p);
 }printf("\n]\n");return 0;
}
