from pathlib import Path
import subprocess
from PIL import Image,ImageDraw,ImageFont
root=Path(__file__).resolve().parents[2]; out=root/'audit/review-claude/visuals'
font=root/'audit/review-claude/generated/current-built.ttf'
renderer=root/'audit/review-claude/render_hinting'
label=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18)
title=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',24)
sample='x e a m n r   0 O 1 I l   { } [ ]   + - ='
rows=[]
for size in (11,12,13,14,16,20):
 for hint in (0,1):
  p=out/f'hint-{size}-{hint}.pgm'
  subprocess.run([str(renderer),str(font),str(size),str(hint),sample,str(p)],check=True)
  im=Image.open(p).convert('RGB')
  rows.append((f'{size}px / '+('ON' if hint else 'OFF'),im))
sheet=Image.new('RGB',(max(im.width*2 for _,im in rows)+170,100+sum(im.height*2+6 for _,im in rows)),'white')
d=ImageDraw.Draw(sheet)
d.text((24,12),'Current build / native TrueType hinting ON vs OFF',font=title,fill='#17212b')
d.text((24,49),'Same TTF; FreeType; no automatic hinter or embedded bitmaps; enlarged 2x. Not Windows.',font=label,fill='#52606d')
y=88
for labeltext,im in rows:
 d.text((24,y+25),labeltext,font=label,fill='#52606d')
 sheet.paste(im.resize((im.width*2,im.height*2),Image.Resampling.NEAREST),(145,y));y+=im.height*2+6
sheet.save(out/'hinting-comparison.png')
print('Saved hinting comparison')
