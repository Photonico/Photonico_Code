"""Review images only. Never writes to the source or earlier audit artifacts."""
from pathlib import Path
import subprocess
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'audit/review-claude/visuals'
OUT.mkdir(parents=True,exist_ok=True)
label=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18)
title=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',24)
fonts=[('Before Claude changes',ROOT/'audit/generated/Photonico-current.ttf'),
       ('After / scripts/build.py output',ROOT/'audit/review-claude/generated/current-built.ttf')]
samples=[('positions','y accents and L middle dot','y ý ÿ   L Ŀ l ŀ'),
         ('dollars','Dollar ligatures and grid widths','$ <$> $> <+> <$> abc'),
         ('marks','HarfBuzz / combining-mark fixes','x̂ r̂ Λ̂ ϕ̂ œ̂   x̀ q̌ x̣ q̥ x̵ x̶'),
         ('multiple-marks','Still incomplete / acute after a precomposed marked base','ḁ́ b   ḍ́ b   ẍ́ b'),
         ('equivalents','Canonical equivalents / before and after','Ω Ω  ά ά  ώ ώ  ΐ ΐ'),
         ('height','Tall accents / ascent remains 1800','O Ő U Ű l ĺ L Ľ')]
for key,description,sample in samples:
 rows=[]
 for i,(name,font) in enumerate(fonts):
  dest=OUT/f'{key}-{i}.png'
  subprocess.run(['hb-view',str(font),sample,'--font-size=62','--margin=18','--output-file='+str(dest)],check=True)
  rows.append((name,Image.open(dest).convert('RGB')))
 sheet=Image.new('RGB',(max(1200,max(im.width for _,im in rows)+48),98+sum(im.height+40 for _,im in rows)),'white')
 draw=ImageDraw.Draw(sheet)
 draw.text((24,14),description,fill='#17212b',font=title)
 draw.text((24,49),'HarfBuzz 14.5.0 / 62 px / exact source files recorded in review provenance',fill='#52606d',font=label)
 y=92
 for caption,im in rows:
  draw.text((24,y),caption,fill='#52606d',font=label)
  sheet.paste(im,(24,y+27));y+=im.height+40
 sheet.save(OUT/f'{key}-comparison.png')
print('Rendered',len(samples),'comparisons')
