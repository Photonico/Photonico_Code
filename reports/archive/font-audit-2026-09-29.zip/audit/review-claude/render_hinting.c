#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ft2build.h>
#include FT_FREETYPE_H

/* Exact same font, explicit native bytecode on/off, no automatic hinter.
 * ASCII sample only; not a shaping engine or a Windows screenshot. */
int main(int argc, char **argv) {
  if (argc != 6) return 1;
  FT_Library lib; FT_Face face;
  if (FT_Init_FreeType(&lib) || FT_New_Face(lib, argv[1], 0, &face)) return 2;
  int size=atoi(argv[2]), hint=atoi(argv[3]);
  if (FT_Set_Pixel_Sizes(face, 0, size)) return 3;
  const unsigned char *text=(unsigned char *)argv[4];
  int width=20+(int)(strlen(argv[4])*(size*1200.0/face->units_per_EM+1));
  int height=size*2+20, baseline=size+10;
  unsigned char *pixels=malloc(width*height); memset(pixels,255,width*height);
  FT_Int32 flags=FT_LOAD_NO_BITMAP|FT_LOAD_NO_AUTOHINT;
  if (!hint) flags|=FT_LOAD_NO_HINTING;
  long pen=10*64;
  for (const unsigned char *ch=text; *ch; ch++) {
    if (FT_Load_Char(face,*ch,flags) || FT_Render_Glyph(face->glyph,FT_RENDER_MODE_NORMAL)) return 4;
    FT_GlyphSlot slot=face->glyph; FT_Bitmap *b=&slot->bitmap;
    int origin=(int)((pen+32)/64)+slot->bitmap_left;
    for (int y=0;y<(int)b->rows;y++) for (int x=0;x<(int)b->width;x++) {
      int xx=origin+x, yy=baseline-slot->bitmap_top+y;
      if (xx>=0 && xx<width && yy>=0 && yy<height) {
        unsigned char shade=255-b->buffer[y*b->pitch+x];
        if (shade<pixels[yy*width+xx]) pixels[yy*width+xx]=shade;
      }
    }
    pen+=slot->advance.x;
  }
  FILE *out=fopen(argv[5],"wb"); if (!out) return 5;
  fprintf(out,"P5\n%d %d\n255\n",width,height);
  fwrite(pixels,1,width*height,out); fclose(out); free(pixels);
  FT_Done_Face(face); FT_Done_FreeType(lib);
  return 0;
}
