import CoreText
import CoreGraphics
import Foundation
import ImageIO
let path=CommandLine.arguments[1]
let output=CommandLine.arguments[2]
let provider=CGDataProvider(url:URL(fileURLWithPath:path) as CFURL)!
let font=CTFontCreateWithGraphicsFont(CGFont(provider)!,96,nil,nil)
let width=800, height=580
let context=CGContext(data:nil,width:width,height:height,bitsPerComponent:8,bytesPerRow:0,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue)!
context.setFillColor(CGColor(gray:1,alpha:1));context.fill(CGRect(x:0,y:0,width:width,height:height))
let cell=1200.0/1950.0*96.0
let x=290.0
for i in 0...2 {
 context.setStrokeColor(CGColor(red:0.7,green:0.8,blue:0.9,alpha:1));context.setLineWidth(1)
 context.move(to:CGPoint(x:x+Double(i)*cell,y:35));context.addLine(to:CGPoint(x:x+Double(i)*cell,y:535));context.strokePath()
}
func draw(_ text:String,_ font:CTFont,_ xx:Double,_ yy:Double) {
 let attr=NSAttributedString(string:text,attributes:[NSAttributedString.Key(kCTFontAttributeName as String):font,NSAttributedString.Key(kCTForegroundColorAttributeName as String):CGColor(gray:0.05,alpha:1)])
 let line=CTLineCreateWithAttributedString(attr)
 context.textMatrix = .identity;context.textPosition=CGPoint(x:xx,y:yy);CTLineDraw(line,context)
}
let label=CTFontCreateWithName("Menlo" as CFString,18,nil)
draw("CoreText - generated current-built.ttf",label,30,550)
for (i,sample) in ["xx","x\u{0335}x","x\u{0336}x","x\u{0323}x","x\u{0325}x"].enumerated() {
 let y=450.0-Double(i)*95.0
 let code=sample.unicodeScalars.map{String(format:"%04X",$0.value)}.joined(separator:" ")
 draw(code,label,30,y+10);draw(sample,font,x,y)
}
let image=context.makeImage()!
let dest=CGImageDestinationCreateWithURL(URL(fileURLWithPath:output) as CFURL,"public.png" as CFString,1,nil)!
CGImageDestinationAddImage(dest,image,nil)
if !CGImageDestinationFinalize(dest){fatalError("PNG write failed")}
