from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
# Reuse previous read-only audit function without invoking its old main/output.
code=(ROOT/'audit/metadata/audit_metadata.py').read_text().split('results=[details(p)')[0]
namespace={'__file__':str(ROOT/'audit/metadata/audit_metadata.py')}
exec(compile(code,'audit_metadata.py','exec'),namespace)
namespace['OUT']=OUT
paths=[ROOT/'audit/generated/Photonico-current.ttf',ROOT/'audit/review-claude/generated/current-raw.ttf',ROOT/'audit/review-claude/generated/current-built.ttf']
results=[namespace['details'](p) for p in paths]
(OUT/'metadata.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
s=(ROOT/'00_Regular.sfd').read_text();glyphs={}
for m in re.finditer(r'^StartChar: ([^\n]+)\n(.*?)^EndChar$',s,re.M|re.S):
 name,b=m.groups();w=re.search(r'^Width: (-?\d+)',b,re.M); enc=re.search(r'^Encoding: (-?\d+) (-?\d+) (-?\d+)',b,re.M)
 if w and enc: glyphs[name]={'width':int(w[1]),'unicode':int(enc[2])}
(OUT/'source_widths.json').write_text(json.dumps(glyphs,indent=2)+'\n')
from fontTools.ttLib import TTFont
from collections import Counter
comparisons=[]
for p,r in zip(paths,results):
 f=TTFont(p); w=f['hmtx'].metrics
 mismatches=[{'name':n,'source_width':v['width'],'output_width':w[n][0]} for n,v in glyphs.items() if n in w and v['width']!=w[n][0]]
 comp={'file':str(p.relative_to(ROOT)),'source_width_mismatches':mismatches,'combining':{f'U+{cp:04X}':{'glyph':n,'width':w[n][0],'gdef':f['GDEF'].table.GlyphClassDef.classDefs.get(n)} for cp,n in f.getBestCmap().items() if cp in (0x323,0x325,0x335,0x336,0x200b,0xfeff)},'multiple_USE_MY_METRICS':[]}
 for i,n in enumerate(f.getGlyphOrder()):
  g=f['glyf'][n]
  if g.isComposite() and sum(bool(c.flags&0x200) for c in g.components)>1:comp['multiple_USE_MY_METRICS'].append(n)
 comparisons.append(comp)
 print(str(p.relative_to(ROOT)), 'fixed',r['isFixedPitch'],'panose',r['panose'],'version',r['name_ids']['5'],r['head_fontRevision'],'widths',r['hmtx_width_counts'],'source_mismatches',len(mismatches),'hints',r['hinted_glyph_count'],r['program_bytes'],'gasp',r['gasp'],'excess_codepage',r['excess_codepage_bits'],'checksum',r['bad_checksums'],'glyphs',r['glyph_count'],'cmap',r['cmap_count'],'lsb_xmin',len(r['lsb_xmin_mismatches']))
(OUT/'source_output_comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n')
