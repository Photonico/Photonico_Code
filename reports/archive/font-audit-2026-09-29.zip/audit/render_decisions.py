"""Produce review-only position and clipping specimens; source remains unchanged."""
from pathlib import Path
import subprocess
from PIL import Image, ImageDraw, ImageFont
from fontTools.ttLib import TTFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'audit/visuals'
LABEL = ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf', 18)
TITLE = ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf', 24)
current = ROOT / 'audit/generated/Photonico-current.ttf'
proposal = ROOT / 'audit/generated/position-proof.ttf'
rows = []
for tag, font, caption in [('current', current, 'Current SFD: displaced accents and dot'),
                           ('proposal', proposal, 'Position proposal only: y accents x=-40; L-dot offset=(230,-672)')]:
    dest = OUT / f'positions-{tag}.png'
    subprocess.run(['hb-view', str(font), 'y ý ÿ   u ú ü   L Ŀ l ŀ', '--font-size=90',
                    '--margin=18', '--output-file=' + str(dest)], check=True)
    rows.append((caption, Image.open(dest).convert('RGB')))
sheet = Image.new('RGB', (max(1200, max(im.width for _, im in rows) + 40),
                          105 + sum(im.height + 45 for _, im in rows)), 'white')
draw = ImageDraw.Draw(sheet)
draw.text((24, 15), 'Decision A / Accent and middle-dot placement', fill='#17212b', font=TITLE)
draw.text((24, 52), 'The displacement is a confirmed defect. Exact corrected placement is for visual approval.', fill='#52606d', font=LABEL)
y = 96
for label, im in rows:
    draw.text((24, y), label, fill='#52606d', font=LABEL)
    sheet.paste(im, (24, y + 28))
    y += im.height + 45
sheet.save(OUT / 'decision-positions.png')

# Pillow BASIC gives a stable per-glyph outline sample, without fallback.
# Red guide is the existing OS/2.usWinAscent=1800, not an assumed clipping result.
tt = TTFont(current)
upem = tt['head'].unitsPerEm
size = 190
ff = ImageFont.truetype(str(current), size, layout_engine=ImageFont.Layout.BASIC)
chars = ['O', 'Ő', 'U', 'Ű', 'l', 'ĺ', 'Ľ', 'Q', 'g']
canvas = Image.new('RGB', (1360, 420), 'white')
d = ImageDraw.Draw(canvas)
d.text((24, 15), 'Decision B / Tall accents and current vertical metrics', fill='#17212b', font=TITLE)
d.text((24, 49), 'Blue = baseline; red = 1800-unit WinAscent. Crossing a guide is a clipping risk, not a Windows test.', fill='#52606d', font=LABEL)
baseline = 322
guide = baseline - size * 1800 / upem
d.line((24, baseline, 1336, baseline), fill='#41758d', width=2)
d.line((24, guide, 1336, guide), fill='#b44738', width=2)
for i, char in enumerate(chars):
    x = 40 + 142 * i
    d.text((x, baseline), char, font=ff, fill='#17212b', anchor='ls')
    glyph = tt['glyf'][tt.getBestCmap()[ord(char)]]
    d.text((x, 362), f'U+{ord(char):04X}', font=LABEL, fill='#52606d')
    d.text((x, 388), f'yMax {glyph.yMax}', font=LABEL, fill='#52606d')
canvas.save(OUT / 'decision-height.png')

# Compare canonical equivalents with the actual OpenType shaper. These are
# design review examples, not an assertion that differing glyph IDs are errors.
pairs = [('OHM SIGN / GREEK CAPITAL OMEGA', '\u2126', '\u03a9'),
         ('ANGSTROM SIGN / LATIN CAPITAL A WITH RING', '\u212b', '\u00c5'),
         ('GREEK ALPHA OXIA / ALPHA + COMBINING ACUTE', '\u1f71', '\u03b1\u0301'),
         ('GREEK OMEGA OXIA / OMEGA + COMBINING ACUTE', '\u1f7d', '\u03c9\u0301')]
canvas = Image.new('RGB', (1320, 670), 'white')
d = ImageDraw.Draw(canvas)
d.text((24, 15), 'Decision C / Canonically equivalent input, different outlines', fill='#17212b', font=TITLE)
d.text((24, 52), 'Current SFD export / HarfBuzz; unify outlines or retain deliberate typographic variants?', fill='#52606d', font=LABEL)
for i, (label, a, b) in enumerate(pairs):
    y = 100 + i * 139
    d.text((24, y), label, fill='#52606d', font=LABEL)
    for j, text in enumerate((a, b)):
        dest = OUT / f'canonical-{i}-{j}.png'
        subprocess.run(['hb-view', str(current), text, '--font-size=110', '--margin=3', '--output-file=' + str(dest)], check=True)
        im = Image.open(dest).convert('RGB')
        canvas.paste(im, (670 + j * 250, y - 8))
        d.text((24 + j * 305, y + 40), ' + '.join(f'U+{ord(c):04X}' for c in text), font=LABEL, fill='#52606d')
canvas.save(OUT / 'decision-canonical.png')
print('Decision specimens ready.')
