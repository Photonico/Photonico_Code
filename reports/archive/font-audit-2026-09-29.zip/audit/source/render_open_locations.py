from pathlib import Path
import json
from PIL import Image,ImageFont,ImageDraw
ROOT=Path('/Users/lu/Repos/Photonico_Code');OUT=ROOT/'audit/source'
rows=json.load(open(OUT/'open_contour_details.json'))
LABEL=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18)
TITLE=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',24)
font=ImageFont.truetype(str(ROOT/'audit/generated/Photonico-current.ttf'),750,layout_engine=ImageFont.Layout.BASIC)
sheet=Image.new('RGB',(1220,820),'white');d=ImageDraw.Draw(sheet)
d.text((22,18),'Open paths in context / red marks source geometry, not extra visible ink',font=TITLE,fill='#17212b')
d.text((22,55),'The question-hook path repeats in four glyphs. The tiny prime path is only 1 x 13 font units.',font=LABEL,fill='#52606d')
for name,char,origin,label in [('.notdef',chr(0x10FFFF),(42,725),'Question-hook fragment'),('uni2057','⁗',(665,725),'Tiny fragment at the second prime')]:
 r=next(r for r in rows if r['name']==name);x0,baseline=origin;scale=750/1950
 d.text((x0,110),label,font=LABEL,fill='#17212b')
 d.text((x0,baseline),char,font=font,anchor='ls',fill='#182029')
 ps=[(p['x'],p['y'],p['on_curve']) for p in r['points']];out=[];i=0
 out.append(ps[0][:2]);current=ps[0][:2]
 while i+1<len(ps):
  if ps[i+1][2]:out.append(ps[i+1][:2]);current=ps[i+1][:2];i+=1
  else:
   p0=current;p1=ps[i+1][:2];p2=ps[i+2][:2];p3=ps[i+3][:2]
   for step in range(1,51):
    t=step/50;q=1-t
    out.append((q**3*p0[0]+3*q*q*t*p1[0]+3*q*t*t*p2[0]+t**3*p3[0],q**3*p0[1]+3*q*q*t*p1[1]+3*q*t*t*p2[1]+t**3*p3[1]))
   current=p3;i+=3
 coords=[(x0+x*scale,baseline-y*scale) for x,y in out]
 d.line(coords,fill='#d22c31',width=3)
 cx=sum(p[0] for p in coords)/len(coords);cy=sum(p[1] for p in coords)/len(coords)
 d.ellipse((cx-38,cy-38,cx+38,cy+38),outline='#d22c31',width=2)
 d.line((cx+35,cy-18,cx+110,cy-65),fill='#d22c31',width=2)
 d.text((cx+80,cy-92),'Open path',font=LABEL,fill='#d22c31')
sheet.save(OUT/'decision-open-locations.png')
