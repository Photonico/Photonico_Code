"""Read-only original SFD; exports temporary proof fonts for review."""
import fontforge,pathlib,json,math
ROOT=pathlib.Path('/Users/lu/Repos/Photonico_Code')
NAMES=['.notdef','backslash.ss06','uni2BD1','uni2370','uni225F','uni2057']
records=[]
f=fontforge.open(str(ROOT/'00_Regular.sfd'))
for name in NAMES:
 g=f[name];l=g.foreground
 for i,c in enumerate(l):
  if not c.closed and len(c)>1:
   pts=[{'x':p.x,'y':p.y,'on_curve':p.on_curve} for p in c]
   records.append({'name':name,'contour':i,'points':pts,'bbox':c.boundingBox(),'start':(c[0].x,c[0].y),'end':(c[-1].x,c[-1].y),'endpoint_distance':math.hypot(c[0].x-c[-1].x,c[0].y-c[-1].y)})
   c.closed=True
   l[i]=c
 g.foreground=l
f.generate(str(ROOT/'audit/source/open-closed-proof.ttf'))
f.close()
f=fontforge.open(str(ROOT/'00_Regular.sfd'))
for name in NAMES:
 g=f[name];l=g.foreground
 for i in reversed(range(len(l))):
  c=l[i]
  if not c.closed and len(c)>1:
   if name=='backslash.ss06':
    c.closed=True;l[i]=c
   else:del l[i]
 g.foreground=l
f.generate(str(ROOT/'audit/source/open-cleaned-proof.ttf'))
f.close()
(ROOT/'audit/source/open_contour_details.json').write_text(json.dumps(records,indent=2))
for r in records:print(r['name'],r['bbox'],'start',r['start'],'end',r['end'],'distance',r['endpoint_distance'])
