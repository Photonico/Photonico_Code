import fontforge,json,pathlib,collections
base=pathlib.Path('/Users/lu/Repos/Photonico_Code')
f=fontforge.open(str(base/'00_Regular.sfd'))
def combine(t,u):
 a,b,c,d,e,ff=t;A,B,C,D,E,F=u
 return (a*A+c*B,b*A+d*B,a*C+c*D,b*C+d*D,a*E+c*F+e,b*E+d*F+ff)
def boxes(name,t=(1,0,0,1,0,0)):
 g=f[name]; result=[]
 for c in g.foreground:
  if len(c)>1: result.append(c.transform(t).boundingBox())
 for ref,trans,selected in g.references:result+=boxes(ref,combine(t,trans))
 return result
D=json.load(open(base/'audit/source/source_geometry.json'))
for row in D['glyphs']:
 row['all_layer_bbox']=row.get('all_layer_bbox',row['bbox'])
 bs=boxes(row['name'])
 row['bbox']= (min(b[0] for b in bs),min(b[1] for b in bs),max(b[2] for b in bs),max(b[3] for b in bs)) if bs else (0,0,0,0)
 row['visible_resolved_contours']=len(bs)
(base/'audit/source/source_geometry.json').write_text(json.dumps(D,ensure_ascii=False,indent=2))
print('non auxiliary Latin Greek bounds',[(r['name'],r['unicode'],r['bbox']) for r in D['glyphs'] if 0<=r['unicode']<1000 and (r['bbox'][0]<-200 or r['bbox'][2]>1400 or r['bbox'][3]>1800 or r['bbox'][1]<-600)])
print('source glyph all layer bbox includes auxiliary layers, row bbox now resolved foreground without isolated points')
f.close()
