import fontforge, json, re, collections, pathlib
base=pathlib.Path('/Users/lu/Repos/Photonico_Code')
source=base/'00_Regular.sfd'
lines=source.read_text().splitlines()
line_map={}
current=None
for i,s in enumerate(lines,1):
    if s.startswith('StartChar: '):
        current=s.split(': ',1)[1]; line_map[current]={'start':i,'refer_lines':[],'point_lines':[]}
    if current and s.startswith('Refer: '): line_map[current]['refer_lines'].append({'line':i,'text':s})
    if current and re.match(r'^ ?-?[\d.]+ -?[\d.]+ m ',s): line_map[current]['point_lines'].append({'line':i,'text':s})
    if current and s=='EndChar':line_map[current]['end']=i;current=None
f=fontforge.open(str(source))
data=[]
for g in f.glyphs():
    layer=g.foreground
    one=[];degenerate=[]; open_cs=[]
    contour_details=[]
    for ci,c in enumerate(layer):
        pts=[(p.x,p.y,int(p.on_curve)) for p in c]
        if len(c)==1:one.append({'index':ci,'points':pts})
        if not c.closed:open_cs.append(ci)
        distinct=set((p.x,p.y) for p in c)
        if len(distinct)<=1:degenerate.append(ci)
        contour_details.append({'index':ci,'length':len(c),'closed':bool(c.closed),'clockwise':c.isClockwise(),'bbox':c.boundingBox()})
    row={'name':g.glyphname,'unicode':g.unicode,'width':g.width,'bbox':g.boundingBox(),'refs':g.references,'contours':len(layer),'one_points':one,'degenerate_contours':degenerate,'open_contours':open_cs,'validation':g.validate(True),'lines':line_map.get(g.glyphname,{}),'contour_details':contour_details}
    data.append(row)
result={'source':str(source),'fontforge_version':fontforge.version(),'glyphs':data,'metadata':{'ascent':f.ascent,'descent':f.descent,'em':f.em}}
(base/'audit/source/source_geometry.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print('glyph_count',len(data))
print('width_counts',collections.Counter(r['width'] for r in data))
print('onepoint_glyphs',sum(bool(r['one_points']) for r in data),'onepoint_contours',sum(len(r['one_points']) for r in data))
print('validation_masks',collections.Counter(r['validation'] for r in data))
print('exceed_y1800',[(r['name'],r['unicode'],r['bbox']) for r in data if r['bbox'][3]>1800])
print('below_y600',[(r['name'],r['unicode'],r['bbox']) for r in data if r['bbox'][1]<-600])
for r in data:
    if r['name'] in ['oe','yacute','ydieresis','uacute','udieresis','Ldot','dollar.spacer','dollar.ss04','dollar','G']:
        print({k:v for k,v in r.items() if k!='contour_details'})
f.close()
