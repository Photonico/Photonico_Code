from pathlib import Path
from PIL import Image,ImageFont,ImageDraw,ImageChops
import subprocess,json
ROOT=Path('/Users/lu/Repos/Photonico_Code');OUT=ROOT/'audit/source';HB='/opt/homebrew/bin/hb-view'
NAMES=['.notdef','backslash.ss06','uni2BD1','uni2370','uni225F','uni2057']
FONTS={'current':ROOT/'audit/generated/Photonico-current.ttf','closed':OUT/'open-closed-proof.ttf','cleaned':OUT/'open-cleaned-proof.ttf'}
SIZES=[13,16,24,72,240,1200]
imgs={};diff=[]
for name in NAMES:
 for sz in SIZES:
  for variant,font in FONTS.items():
   out=OUT/f'{name.lstrip(".")}-{variant}-{sz}.png'
   subprocess.run([HB,str(font),'--glyphs',name,f'--font-size={sz}','--margin=12','--output-file='+str(out)],check=True)
   imgs[(name,variant,sz)]=Image.open(out).convert('RGB')
  orig=imgs[(name,'current',sz)]
  for var in ['closed','cleaned']:
   prop=imgs[(name,var,sz)]
   if orig.size!=prop.size:dd={'dimension_difference':[orig.size,prop.size]}
   else:
    d=ImageChops.difference(orig,prop);dd={'difference_bbox':d.getbbox(),'changed_pixels':sum(1 for p in d.convert('L').getdata() if p),'max_channel_difference':max(b for a,b in d.getextrema())}
   diff.append({'glyph':name,'size_px':sz,'variant':var,**dd})
LABEL=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18)
SMALL=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',15)
TITLE=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',24)
rowh=340;sheet=Image.new('RGB',(1140,140+rowh*6),'white');d=ImageDraw.Draw(sheet)
d.text((22,18),'Decision C / Six open paths: current and isolated review variants',font=TITLE,fill='#17212b')
d.text((22,53),'Proof fonts only. Source SFD unchanged. Black: actual HarfBuzz/Cairo raster at 240 px.',font=LABEL,fill='#52606d')
for x,label in [(240,'Current source export'),(525,'Close the open path'),(810,'Remove small open path*')]:d.text((x,95),label,font=LABEL,fill='#17212b')
for j,name in enumerate(NAMES):
 y=140+j*rowh;d.line((20,y-8,1120,y-8),fill='#dde3e8',width=1)
 d.text((22,y+18),name,font=LABEL,fill='#17212b')
 if name=='backslash.ss06':label='Whole glyph is the open path.\nStart and end already coincide.\n*Close only; never remove.'
 elif name=='uni2057':label='Tiny 1 x 13 unit path.\nAn almost invisible extra segment.'
 else:label='97 x 66 unit path at the\nlower-left edge of question hook.'
 d.multiline_text((22,y+60),label,font=SMALL,spacing=6,fill='#52606d')
 for k,var in enumerate(['current','closed','cleaned']):
  im=imgs[(name,var,240)];sheet.paste(im,(240+k*285,y))
  rs=next(r for r in diff if r['glyph']==name and r['size_px']==240 and r['variant']==('closed' if var=='closed' else 'cleaned')) if var!='current' else None
  if rs:d.text((240+k*285,y+302),f"Changed pixels: {rs.get('changed_pixels','size differs')}",font=SMALL,fill='#52606d')
sheet.save(OUT/'decision-open-contours.png')
# Extreme zoom to expose the small paths. Crop common coordinates of the rendered
# glyphs using the difference bounding rectangle, with a fixed margin.
rows=[]
for name in ['.notdef','uni2057']:
 a=imgs[(name,'current',1200)];b=imgs[(name,'cleaned',1200)];c=imgs[(name,'closed',1200)]
 box=ImageChops.difference(a,b).getbbox()
 if not box:box=ImageChops.difference(a,c).getbbox()
 if not box:continue
 x0,y0,x1,y1=box;side=max(100,x1-x0,y1-y0)+80;cx=(x0+x1)//2;cy=(y0+y1)//2;box=(cx-side//2,cy-side//2,cx+side//2,cy+side//2)
 rows.append((name,[im.crop(box).resize((290,290),Image.Resampling.NEAREST) for im in [a,c,b]]))
zoom=Image.new('RGB',(990,120+len(rows)*345),'white');d=ImageDraw.Draw(zoom)
d.text((22,18),'Open-path detail / nearest-neighbor crop of 1200 px raster',font=TITLE,fill='#17212b')
d.text((22,54),'Current                    Closed only                 Small path removed',font=LABEL,fill='#52606d')
for j,(name,ims) in enumerate(rows):
 y=100+j*345;d.text((22,y),name,font=LABEL,fill='#17212b')
 for k,im in enumerate(ims):zoom.paste(im,(22+k*320,y+28))
zoom.save(OUT/'decision-open-details.png')
(OUT/'open_pixel_differences.json').write_text(json.dumps(diff,indent=2))
print(json.dumps([r for r in diff if r['size_px'] in [13,24,240,1200]],indent=2))
