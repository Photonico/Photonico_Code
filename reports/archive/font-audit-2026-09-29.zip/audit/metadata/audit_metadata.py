#!/usr/bin/env python3
"""Read-only metadata/coverage audit of all released Photonico TTFs."""
import json, logging, re, struct, hashlib, io
from pathlib import Path
from collections import Counter
from fontTools.ttLib import TTFont
from fontTools.pens.boundsPen import BoundsPen
from fontTools.ttLib.tables.O_S_2f_2 import calcCodePageRanges, intersectUnicodeRanges
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent

def names(f,n):
    return sorted(set(x.toUnicode() for x in f['name'].names if x.nameID==n))
def version_key(p):
    return tuple(map(int,re.search(r' (\d+\.\d+) ',p.name)[1].split('.')))
def details(p):
    logs=io.StringIO(); h=logging.StreamHandler(logs); logging.getLogger('fontTools').addHandler(h)
    f=TTFont(p,checkChecksums=2)
    for tag in f.keys(): f[tag]
    glyf=f['glyf']; cmap=f.getBestCmap(); glyphset=f.getGlyphSet(); os2=f['OS/2']; head=f['head']; hhea=f['hhea']
    draw_errors=[]; hinted=[]; bounds={}; actual_bounds={}; bad_lsb=[]; unequal=[]; over_top=[]; under_bottom=[]; blank=[]; empty_encoded=[]
    for n in f.getGlyphOrder():
        g=glyf[n]
        if getattr(g,'program',None) and g.program.getBytecode(): hinted.append(n)
        if g.numberOfContours:
            bounds[n]=[getattr(g,k) for k in ('xMin','yMin','xMax','yMax')]
            pen=BoundsPen(glyphset)
            try:
                glyphset[n].draw(pen)
                actual_bounds[n]=list(pen.bounds) if pen.bounds else None
            except Exception as exc:
                draw_errors.append([n,type(exc).__name__,str(exc)])
            if f['hmtx'][n][1] != g.xMin: bad_lsb.append([n,f['hmtx'][n][1],g.xMin])
            if g.yMax>os2.usWinAscent: over_top.append([n,g.yMax])
            if g.yMin<-os2.usWinDescent: under_bottom.append([n,g.yMin])
        else: blank.append(n)
    for cp,n in cmap.items():
        w=f['hmtx'][n][0]
        if w not in (0,1200): unequal.append([f'U+{cp:04X}',n,w])
        if n in blank: empty_encoded.append([f'U+{cp:04X}',n])
    unicode_maps=[(t.platformID,t.platEncID,t.format,t.cmap) for t in f['cmap'].tables if t.isUnicode()]
    cmap_disagreements=[]
    for cp in sorted(set().union(*(set(t[3]) for t in unicode_maps))):
        entries={str(t[:3]):t[3][cp] for t in unicode_maps if cp in t[3]}
        if len(set(entries.values()))>1: cmap_disagreements.append([f'U+{cp:04X}',entries])
    declared_cp=[i for i in range(64) if ((os2.ulCodePageRange1|(os2.ulCodePageRange2<<32))>>i)&1]
    declared_ur=[i for i in range(128) if ((os2.ulUnicodeRange1|(os2.ulUnicodeRange2<<32)|(os2.ulUnicodeRange3<<64)|(os2.ulUnicodeRange4<<96))>>i)&1]
    derived_cp=sorted(calcCodePageRanges(set(cmap)))
    derived_ur=sorted(intersectUnicodeRanges(set(cmap)))
    required_ranges={'ascii':(0x20,0x7f),'latin1_printable':(0xa0,0x100),'greek':(0x370,0x400),'cyrillic_basic':(0x400,0x460),'braille':(0x2800,0x2900),'box_drawing':(0x2500,0x2580),'block_elements':(0x2580,0x25a0),'combining_diacritics':(0x300,0x370),'powerline':(0xe0a0,0xe0d8)}
    coverage={k:{'present':sum(cp in cmap for cp in range(a,b)),'slots':b-a,'missing':[f'U+{cp:04X}' for cp in range(a,b) if cp not in cmap]} for k,(a,b) in required_ranges.items()}
    checksums={}
    data=p.read_bytes()
    for tag,e in f.reader.tables.items():
        tab=bytearray(data[e.offset:e.offset+e.length])
        if tag=='head': tab[8:12]=b'\0'*4
        tab.extend(b'\0'*((-len(tab))%4))
        actual=sum(struct.unpack(f'>{len(tab)//4}I',tab))&0xffffffff
        if actual!=e.checkSum: checksums[str(tag)]=[e.checkSum,actual]
    padded=data+b'\0'*((-len(data))%4)
    total_checksum=sum(struct.unpack(f'>{len(padded)//4}I',padded))&0xffffffff
    out={'file':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(data).hexdigest(),'size':len(data),'tables':f.keys(),'glyph_count':len(f.getGlyphOrder()),'cmap_count':len(cmap),'head_fontRevision':head.fontRevision,'name_ids':{str(i):names(f,i) for i in (1,2,3,4,5,6,16,17)},'unitsPerEm':head.unitsPerEm,'head_bounds':[getattr(head,k) for k in ('xMin','yMin','xMax','yMax')],'isFixedPitch':f['post'].isFixedPitch,'panose':os2.panose.__dict__,'hmtx_width_counts':dict(Counter(w for w,l in f['hmtx'].metrics.values())),'cmap_width_counts':dict(Counter(f['hmtx'][n][0] for n in set(cmap.values()))),'encoded_nonstandard_widths':unequal,'all_nonstandard_widths':[[n,w] for n,(w,l) in f['hmtx'].metrics.items() if w not in (0,1200)],'lsb_xmin_mismatches':bad_lsb,'hinted_glyph_count':len(hinted),'hinted_glyphs':hinted,'program_bytes':{tag:len(f[tag].program.getBytecode()) for tag in ('fpgm','prep') if tag in f},'cvt_count':len(f['cvt '].values) if 'cvt ' in f else 0,'gasp':getattr(f.get('gasp'),'gaspRange',{}),'maxp':f['maxp'].__dict__,'metrics':{k:getattr(os2,k) for k in ('sTypoAscender','sTypoDescender','sTypoLineGap','usWinAscent','usWinDescent','fsSelection','sxHeight','sCapHeight','usFirstCharIndex','usLastCharIndex','usMaxContext')},'hhea':{k:getattr(hhea,k) for k in ('ascent','descent','lineGap','advanceWidthMax','minLeftSideBearing','minRightSideBearing','xMaxExtent')},'bounds_above_win':over_top,'bounds_below_win':under_bottom,'coverage':coverage,'declared_codepage_bits':declared_cp,'fontTools_derived_codepage_bits':derived_cp,'excess_codepage_bits':sorted(set(declared_cp)-set(derived_cp)),'declared_unicode_bits':declared_ur,'fontTools_derived_unicode_bits':derived_ur,'excess_unicode_bits':sorted(set(declared_ur)-set(derived_ur)),'cmap_disagreements':cmap_disagreements,'empty_encoded':empty_encoded,'bad_checksums':checksums,'whole_font_checksum':hex(total_checksum),'fontTools_logs':logs.getvalue(),'draw_errors':draw_errors}
    logging.getLogger('fontTools').removeHandler(h)
    if '1.5' in p.name or 'current' in p.name:
        (OUT/('current_glyph_bounds.json' if 'current' in p.name else 'latest_glyph_bounds.json')).write_text(json.dumps({'stored':bounds,'actual':actual_bounds},indent=2)+'\n')
    return out
results=[details(p) for p in sorted((ROOT/'Releases').glob('*.ttf'),key=version_key)]
if (ROOT/'audit/generated/Photonico-current.ttf').exists():
    results.append(details(ROOT/'audit/generated/Photonico-current.ttf'))
(OUT/'release_metadata.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
for r in results:
    print(f"{r['file']}: revision={r['head_fontRevision']:.5f} version={r['name_ids']['5']} fixed={r['isFixedPitch']} widths={r['hmtx_width_counts']} hinted={r['hinted_glyph_count']}/{r['glyph_count']} checksums={len(r['bad_checksums'])} whole={r['whole_font_checksum']}")
