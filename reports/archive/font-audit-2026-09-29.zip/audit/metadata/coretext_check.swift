import CoreText
import CoreGraphics
import Foundation
for path in CommandLine.arguments.dropFirst() {
 let url = URL(fileURLWithPath:path)
 guard let provider = CGDataProvider(url:url as CFURL), let cgfont = CGFont(provider) else { print("FAILED: \(path)"); continue }
 let font = CTFontCreateWithGraphicsFont(cgfont, 13, nil, nil)
 let traits = CTFontGetSymbolicTraits(font)
 print("\(path): name=\(CTFontCopyFullName(font)) traits=\(traits.rawValue) monoSpace=\(traits.contains(.traitMonoSpace)) ascent=\(CTFontGetAscent(font)) descent=\(CTFontGetDescent(font))")
}
