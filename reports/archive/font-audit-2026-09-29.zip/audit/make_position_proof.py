"""FontForge-only proof. Generates a review font; never saves or edits the SFD.

fontforge -lang=py -script audit/make_position_proof.py
These proposed offsets are visual design choices, not an approved font release.
"""
from pathlib import Path
import fontforge

root = Path(__file__).resolve().parents[1]
font = fontforge.open(str(root / '00_Regular.sfd'))
for name in ('yacute', 'ydieresis'):
    refs = []
    for ref in font[name].references:
        component, matrix = ref[:2]
        if component != 'y':
            matrix = tuple(matrix[:4]) + (-40.0, matrix[5])
        refs.append((component, matrix))
    font[name].references = tuple(refs)
refs = []
for ref in font['Ldot'].references:
    component, matrix = ref[:2]
    if component != 'L':
        matrix = tuple(matrix[:4]) + (230.0, -672.0)
    refs.append((component, matrix))
font['Ldot'].references = tuple(refs)
font.fontname = 'PhotonicoCode-AuditPositionProof'
font.fullname = 'Photonico Code Audit Position Proof'
font.familyname = 'Photonico Code Audit Position Proof'
font.generate(str(root / 'audit/generated/position-proof.ttf'))
font.close()
