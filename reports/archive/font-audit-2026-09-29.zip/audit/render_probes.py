"""Render unchanged fonts with HarfBuzz; compose labeled evidence with Pillow.

Run with a Python providing Pillow, with hb-view on PATH. No fonts are modified.
"""
from pathlib import Path
import subprocess
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'audit/visuals'
OUT.mkdir(parents=True, exist_ok=True)
LABEL = ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf', 18)
TITLE = ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf', 24)
FONTS = [('Release 1.5', ROOT / 'Releases/Photonico 1.5 Regular.ttf'),
         ('Current SFD export', ROOT / 'audit/generated/Photonico-current.ttf')]
CASES = [
    ('oe', 'oe / ligature oe; inspect ink above text', 'coeur cœur œuvre oe œ'),
    ('accents', 'y accents / L middle dot', 'y ý ÿ u ú ü L Ŀ l ŀ'),
    ('dollars', 'Dollar ligatures: default calt', '$ <$> $> <+> <$> abc'),
    ('graves', 'One / two / three backticks', '` `` ``` a`b a``b a```b'),
    ('marks', 'Combining marks: acute, grave, caron, dot/ring below, strokes', 'x́ x̀ q̌ x̣ q̥ x̵ x̶'),
    ('anchors', 'Missing base anchors: x-hat vs r-hat, Lambda-hat, phi-hat, oe-hat', 'x̂ r̂ Λ̂ ϕ̂ œ̂'),
    ('greek', 'Greek chi / neighboring letters', 'αβγ δεζ ηθι κλμ νξο πρσ τυφ χψω'),
    ('caps', 'Tall accents and descenders', 'O Ó Ô Õ Ö Ő Ů L Ĺ Ľ Ļ Q g j p q y'),
]

def render(font, text, dest, size=58, extra=()):
    subprocess.run(['hb-view', str(font), text, f'--font-size={size}',
                    '--margin=12', '--output-file=' + str(dest), *extra], check=True)
    return Image.open(dest).convert('RGB')

for key, description, sample in CASES:
    rows = []
    for i, (name, font) in enumerate(FONTS):
        im = render(font, sample, OUT / f'{key}-{i}.png')
        rows.append((name, im))
    width = max(1100, max(im.width for _, im in rows) + 48)
    height = 94 + sum(im.height + 42 for _, im in rows)
    sheet = Image.new('RGB', (width, height), 'white')
    draw = ImageDraw.Draw(sheet)
    draw.text((24, 16), description, fill='#17212b', font=TITLE)
    draw.text((24, 50), 'HarfBuzz 14.5.0 / hb-view / 58 px; unchanged fonts', fill='#52606d', font=LABEL)
    y = 86
    for name, im in rows:
        draw.text((24, y), name, fill='#52606d', font=LABEL)
        sheet.paste(im, (24, y + 28))
        y += im.height + 42
    sheet.save(OUT / f'{key}-comparison.png')

font = FONTS[1][1]
sample = 'x e m n 0 O l I 1 {} [] != === -> <$> αβχ x̣ q̌'
rows = []
for size in [11, 12, 13, 14, 16, 20, 24]:
    im = render(font, sample, OUT / f'size-{size}.png', size=size)
    rows.append((size, im))
sheet = Image.new('RGB', (max(1200, 120 + max(im.width * 2 for _, im in rows)), 90 + sum(im.height * 2 + 32 for _, im in rows)), 'white')
draw = ImageDraw.Draw(sheet)
draw.text((24, 16), 'Small-size rendering / current source export', fill='#17212b', font=TITLE)
draw.text((24, 50), 'hb-view default rasterization; enlarged 2x nearest-neighbor; not a Windows screenshot', fill='#52606d', font=LABEL)
y = 86
for size, im in rows:
    draw.text((24, y), f'{size} px', fill='#52606d', font=LABEL)
    sheet.paste(im.resize((im.width * 2, im.height * 2), Image.Resampling.NEAREST), (100, y))
    y += im.height * 2 + 32
sheet.save(OUT / 'small-sizes.png')
print('Rendered', len(CASES), 'comparisons and small-size sheet in', OUT)
